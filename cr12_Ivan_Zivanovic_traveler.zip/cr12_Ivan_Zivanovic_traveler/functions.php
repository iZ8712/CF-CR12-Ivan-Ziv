<?php 

function basicstyle_file() {

wp_enqueue_style('bootstrap-css', get_template_directory_uri().'/css/bootstrap.css');
wp_enqueue_style( 'my style sheet', get_template_directory_uri() . '/style.css', array(), rand(111,9999), 'all' ); /*my browser struggled loading the right stylesheet so I added this line of code to help */
wp_enqueue_script('bootstrap-js', get_template_directory_uri().'/css/bootstrap.js', array(), true);

}

add_action('wp_enqueue_scripts', 'basicstyle_file');

function register_navwalker(){
    require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
    
    register_nav_menus( array(
        'primary' => __( 'Top Menu', 'cr12_Ivan_Zivanovic_travler' ),
    ) );
}

add_action( 'after_setup_theme', 'register_navwalker' );

function set_excerpt_length() {
    return 50;
}

add_filter('excerpt_length', 'set_excerpt_length');

add_theme_support( 'post_thumbnails' );

function register_widgets(){
    register_sidebar(array(
        'name'=> 'Sidebar',
        'id'=> 'sidebar',
        'before_widget'=> '<div class="sidebar">',
        'after_widget'=> '</div>'
    ));
}

add_action('widgets_init', 'register_widgets');

add_theme_support( 'post-thumbnails' );

function wpb_move_comment_field_to_bottom( $fields ) {
    $comment_field = $fields['comment'];
    unset( $fields['comment'] );
    $fields['comment'] = $comment_field;
    return $fields;
    }
      
    add_filter( 'comment_form_fields', 'wpb_move_comment_field_to_bottom'); 

?>