<?php get_header(); ?>

<div class="container">
 <div class="row mt-5 mb-5">

<?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
        <h3 class="col-12 mb-4"><?php the_title(); ?></h3>
        <div class="col-12 mb-4"><p><?php the_time('F j, Y g:i a'); ?> by the author <?php the_author(); ?></p></div>
        <div class="col-12 mb-4"><?php the_content(); ?></div>
        <div class="col-12 mb-4"><?php comments_template(); ?></div>
    <?php endwhile; ?>
<?php else :?>
    <?php__('No Posts found'); ?>
<?php endif; ?>

<?php if(is_active_sidebar( 'sidebar' )): ?>
        <p class="col-12 mb-4"><?php dynamic_sidebar('Sidebar'); ?></p>
<?php endif;?>

</div>
</div>

<?php get_footer(); ?>

