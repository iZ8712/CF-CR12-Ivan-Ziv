<?php get_header(); ?>

<div class="container justify-content-center">

<div class="row mt-5 mb-5 justify-content-center">

<h1>News</h1>

<?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
    <div class="col-12 card mt-3 mb-3" >
  <div class="row no-gutters">
    <div class="col-md-4">
        <?php if(has_post_thumbnail()): ?>
            <?php the_post_thumbnail( 'full', array( 'class' => 'card-img img-responsive thumb' ) ); ?>
        <?php endif; ?>
        </div>
    <div class="col-md-8">
      <div class="card-body">
        <h3 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></h3></a>
        <p class="card-text"><?php the_time('F j, Y g:i a'); ?></p>
        <p class="card-text"><small class="text-muted"><?php the_content(); ?></small></p>
      </div>
    </div>
  </div>
</div>
    <?php endwhile; ?>
<?php else :?>
    <?php__('No Posts found'); ?>
<?php endif; ?>

</div>




</div>

<?php get_footer(); ?>