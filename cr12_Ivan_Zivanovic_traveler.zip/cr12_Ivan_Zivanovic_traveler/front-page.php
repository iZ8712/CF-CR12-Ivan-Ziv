<?php get_header(); ?>


<div class="container">

<div class="row mt-5 mb-5 justify-content-around">

<img class="col-xs-12 col-sm-12 col-md-8 col-lg-4 img-thumbnail circle" src="<?php bloginfo('template_directory');?>/images/homer.jpg" alt="">
<div class="col-xs-12 col-sm-12 col-md-8 col-lg-4">
    <h2>Mount Everest</h2>
    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, 
        sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, 
        no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
</div>




</div>


<div class="row justify-content-around mt-5 mb-5">

<h1 class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">Latest Posts</h1>

<div class="mb-4 col-xs-12 col-sm-12 col-md-8 col-lg-4 card bg-white text-white border-0">
<img src="<?php bloginfo('template_directory');?>/images/post5.jpg"  class="card-img" alt="...">
  <div class="card-img-overlay">
    <h2 class="card-title text-center"><a class="cardT" href="index.php">Jungle</a></h2>
  </div>
</div>

<div class="mb-4 col-xs-12 col-sm-12 col-md-8 col-lg-4 card bg-white text-white border-0">
<img src="<?php bloginfo('template_directory');?>/images/post2.jpg"  class="card-img" alt="...">
  <div class="card-img-overlay">
  <h2 class="card-title text-center"><a class="cardT" href="index.php">Mountains</a></h2>
  </div>
</div>

<div class="mb-4 col-xs-12 col-sm-12 col-md-8 col-lg-4 card bg-white text-white border-0">
<img src="<?php bloginfo('template_directory');?>/images/post3.jpg"  class="card-img" alt="...">
  <div class="card-img-overlay">
  <h2 class="card-title text-center"><a class="cardT" href="index.php">Desert</a></h2>
  </div>
</div>

</div>

<h2 class="text-center">Our recommendation for you</h2>

<div class="d-flex justify-content-around">
  
  <iframe width="1000" height="600" src="https://www.youtube.com/embed/llq8Rjm6wKc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>  

</div>



  
 





<?php get_footer(); ?>